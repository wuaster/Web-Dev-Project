<template>
  <div class="home">
    <br><br><br><h1>Welcome to the home page of Nathalie, Brandon and Sameer's CPS530 final project.</h1>
    <img src="w-dogs.jpg" alt="" width=100% height=25%>
     <br><h1> Browse through the pages using the icon on the top left corner of this page!</h1>
  </div>
</template>

<script>

export default {
  name: 'home',

}
</script>
<style>
h1{
  font-family:Arial, Helvetica, sans-serif;
  text-align: center;

}
</style>
