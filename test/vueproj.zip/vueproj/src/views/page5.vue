<template>
<body>
  <div>
    <h1 style = "font-family: Calibri; text-align:center;font-size:60px">Conclusion</h1>
    <br>
        <h2 style = "font-family: Calibri; text-align:center">My Experience With The Frameworks</h2>
        <br>
        <p class= "blocktext text">My experience with Vue and Veutify was interesting and went very smoothly.
             One of the pivotal reasons I enjoy using Vuejs is because it is relatively easy to understand. Vuetify\'s documentation 
            is also quite clear and concise, saving time for developers that are new to the framework.</p>
        <p class= "blocktext text">Unlike a lot of the other JS frameworks, Vue.js offers a very 
            simple integration as a lot of the web page's components can be held within a 
            considerably small pool of files. Hence making it much easier to reuse and modify components when working on new projects.</p>
        <p class= "blocktext text">Furthermore, Vuetify's base layout is considerably easy for users to 
            navigate and quite pleasing to the eye without necessarily being overpowering. When it comes to material design, 
            Vuejs is a great option as it allows users to easily create designs that are both visually appealing as well as functional.</p>
        <br>
        <p class= "blocktext text">My experience with Flask also went very smoothly. 
            Flask is a web application framework written in python</p>
  </div>
  </body>   
</template>




<script>
// @ is an alias to /src
export default {
}
</script>
<style>
body {color: darkgoldenrod}
h3 {color: darkgoldenrod;}
h2 {color: steelblue;}

.box{
    margin: auto;
    border: 3px double steelblue; 
    width:500px; height:700px;
    padding:10px;
}

p.blocktext {
    margin-left: auto;
    margin-right: auto;
    width: 40em;
    font-size: 18px;
}
</style>
