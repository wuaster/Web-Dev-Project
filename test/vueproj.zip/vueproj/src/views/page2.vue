<template>
<body>
  <div>
      <h1>How to install Vue.js and Vuetify.js </h1>
      <div style="text-align: center; " class="center">
          <h3>Steps</h3>
          <p>1. Open terminal and type in "vue create filename".</p>
          <img src="step1.png" class="imgsizing">
          <p>2. Select "Manually select features" using arrows and enter on keyboard.</p>
          <img src="step2.png" class="imgsizing">
          <p>3. Babel and Linter should already be selected. Select Router using arrows and space bar, then hit enter when finished.</p>
          <img src="step3.png" class="imgsizing">
          <p>4. Type in "y/Y" and hit enter.</p>
          <img src="step4.png" class="imgsizing">
          <p>5. Select "ESlint with error prevention only".</p>
          <img src="step5.png" class="imgsizing">
          <p>6. Select "Lint on save".</p>
          <img src="step6.png" class="imgsizing">
          <p>7. Select "In package.json".</p>
          <img src="step7.png" class="imgsizing">
          <p>8. Type in "n/N".</p>
          <img src="step8.png" class="imgsizing">
          <p>9. The installation will automatically begin upon hitting enter to the previous question. This is part of what it should look like. </p>
          <img src="step9.png" class="imgsizing">
          <p>10. To start running Vue.js, type "npm run serve" in terminal.</p>
          <img src="step11.png" class="imgsizing">
          <p>11. To view your page, go to the local host in your preferred web browser.</p>
          <img src="step12.png" class="imgsizing">
          
      </div>
        <br><br><br><br>
      <h1>How to install Flask</h1> 
      <div style="text-align: center;" class="center">  
            <h3>Steps</h3>
            <ol style="text-align: left;">
                <li>As a prerequiste: Python: <br>
                For instructions follow this <a href= "https://www.python.org/downloads/"> npm installation tutorial</a></li>
                <li>
                    Open command prompt and type: <br>
                    # install with pip <br>
                    pip install Flask 
                </li>
                <li>
                    Set up the project structure like the following:
                    <br>
                    <img src="flask.jpg">

                </li>
                <li>
                    Congratulations you have successfully installed flask
                </li>
    
            </ol>  
        </div>
  </div>
  </body>
</template>

<style>
body {color: darkgoldenrod}
h3 {color: darkgoldenrod;}
h2 {color: steelblue;}

.box{
    margin: auto;
    border: 3px double steelblue; 
    width:500px; height:700px;
    padding:10px;
}

p.blocktext {
    margin-left: auto;
    margin-right: auto;
    width: 40em;
    font-size: 18px;
}
.imgsizing{
    width:90%;
    height: 90%;
}
</style>